import { CREATE_ORDER_FIX_MESSAGE } from 'components/FixMessage/modules/FixMessage'
// ------------------------------------
// Constants
// ------------------------------------

// ------------------------------------
// Actions
// ------------------------------------
export function createOrderFixMessage (data) {
  return (dispatch, getState) => {
    dispatch({
      type: CREATE_ORDER_FIX_MESSAGE,
      payload: data
    })
  }
}

export const actions = {
  createOrderFixMessage
}

// ------------------------------------
// Action Handlers
// ------------------------------------
const ACTION_HANDLERS = {
  [CREATE_ORDER_FIX_MESSAGE]: (state, action) => {
    return action.payload
  }
}

// ------------------------------------
// Reducer
// ------------------------------------
const initialState = 0
export default function createOrderReducer (state = initialState, action) {
  const handler = ACTION_HANDLERS[action.type]

  return handler ? handler(state, action) : state
}

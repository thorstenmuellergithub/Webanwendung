// We only need to import the modules necessary for initial render
import CoreLayout from '../layouts/CoreLayout/CoreLayout'
import CreateOrder from './CreateOrder'
import Orders from './Orders'
import ViewOrder from './ViewOrder'
import CancelOrder from './CancelOrder'
import Login from './Login'

/*  Note: Instead of using JSX, we recommend using react-router
    PlainRoute objects to build route definitions.   */

export const createRoutes = (store) => {
  function checkAuth (nextState, replace) {
    if (nextState.location.pathname !== '/') {
      if (!(store.getState().Login &&
        store.getState().Login.accountNumber &&
        store.getState().Login.accountNumber !== '')) {
        replace({
          pathname: '/',
          state: { nextPathname: nextState.location.pathname }
        })
      }
    }
  }

  function onEnter (nextState, replace) {
    checkAuth(nextState, replace)
  }

  function onChange(prevState, nextState, replace) {
    checkAuth(nextState, replace)
  }

  return {
    path: '/',
    component: CoreLayout,
    indexRoute: Login(store),
    onEnter: onEnter,
    onChange: onChange,
    childRoutes: [
      CreateOrder(store),
      Orders(store),
      ViewOrder(store),
      CancelOrder(store)
    ]
  }
}

/*  Note: childRoutes can be chunked or otherwise loaded programmatically
    using getChildRoutes with the following signature:

    getChildRoutes (location, cb) {
      require.ensure([], (require) => {
        cb(null, [
          // Remove imports!
          require('./Counter').default(store)
        ])
      })
    }

    However, this is not necessary for code-splitting! It simply provides
    an API for async route definitions. Your code splitting should occur
    inside the route `getComponent` function, since it is only invoked
    when the route exists and matches.
*/

export default createRoutes

import { CREATE_QUOTE_REQUEST_FIX_MESSAGE } from 'components/FixMessage/modules/FixMessage'
// ------------------------------------
// Constants
// ------------------------------------

// ------------------------------------
// Actions
// ------------------------------------
export function createQuoteRequest (data) {
    return (dispatch, getState) => {
        dispatch({
            type: CREATE_QUOTE_REQUEST_FIX_MESSAGE,
            payload: data
        })
    }
}

export const actions = {
    createQuoteRequest
}

// ------------------------------------
// Action Handlers
// ------------------------------------
const ACTION_HANDLERS = {
    [CREATE_QUOTE_REQUEST_FIX_MESSAGE]: (state, action) => {
        return action.payload
    }
}

// ------------------------------------
// Reducer
// ------------------------------------
const initialState = 0
export default function createOrderReducer (state = initialState, action) {
    const handler = ACTION_HANDLERS[action.type]

    return handler ? handler(state, action) : state
}

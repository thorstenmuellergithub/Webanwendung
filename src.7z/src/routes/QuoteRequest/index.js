import { injectReducer } from '../../store/reducers'

export default (store) => ({
    path: 'QuoteRequest',
    /*  Async getComponent is only invoked when route matches   */
    getComponent (nextState, cb) {
        /*  Webpack - use 'require.ensure' to create a split point
         and embed an async module loader (jsonp) when bundling   */
        require.ensure([], (require) => {
            /*  Webpack - use require callback to define
             dependencies for bundling   */
            const Counter = require('./containers/QuoteRequestContainer').default

            const reducer = require('./modules/QuoteRequest').default
            const fixMessage = require('components/FixMessage/modules/FixMessage').default

            injectReducer(store, { key: 'FixMessage', reducer: fixMessage })
            injectReducer(store, { key: 'QuoteRequest', reducer })

            /*  Return getComponent   */
            cb(null, Counter)

            /* Webpack named bundle   */
        }, 'QuoteRequest')
    }
})

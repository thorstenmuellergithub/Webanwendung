import React from 'react'
import moment from 'moment'
import FixMessage from 'components/FixMessage'
import PureInput from 'components/PureInput'
import { reduxForm, addArrayValue } from 'redux-form'
export const fields = ['MsgType', 'QuoteReqID', 'SendingTime', 'ExDestination', 'NoRelatedSym', 'SecurityIDSource', 'SecurityID']

const timestamp = moment().format('YYYYMMDD-HH:mm:ss:SSS')
const validate = values => {
    const errors = {}
   /* if(!values.BeginString){
        errors.BeginString = 'required'
    }

    if(!values.MsgType){
        errors.MsgType = 'required'
    }
    */return errors
}

export default class QuoteRequest extends React.Component{

    handleSubmit = (e) => {
        // Prevent refreshing form upon first submit
        //e.preventDefault()
        this.props.cleanFixMessage()
        this.props.createQuoteRequest(e)
    }
    componentDidMount () {
        this.props.cleanFixMessage()
    }

    render(){
        const {
            fields: {MsgType, QuoteReqID, SendingTime, ExDestination, NoRelatedSym, SecurityIDSource, SecurityID},
            handleSubmit, resetForm, submitting } = this.props

        return <div>
            <h4>Quote Request</h4>
            <form onSubmit={handleSubmit(this.handleSubmit)}>
                <div className='form-group'>
                    <label className='col-sm-2 control-label' htmlFor='MsgType'>MsgType</label>
                    <div className='col-sm-10'>
                        <PureInput type="text" className='form-control' disabled field={MsgType} />
                    </div>
                </div>
                <div className='form-group'>
                    <label className='col-sm-2 control-label'>QuoteReqID</label>
                    <div className='col-sm-10'>
                        <PureInput type="text" className='form-control'  field={QuoteReqID} />
                    </div>
                </div>
                <div className='form-group'>
                    <label className='col-sm-2 control-label'>ExDestination</label>
                    <div className='col-sm-10'>
                        <PureInput type="text" className='form-control'  field={ExDestination} />
                    </div>
                </div>
                <div className='form-group'>
                    <label className='col-sm-2 control-label'>NoRelatedSym</label>
                    <div className='col-sm-10'>
                        <PureInput type="text" className='form-control'  field={NoRelatedSym} />
                    </div>
                </div>
                <div className='form-group'>
                    <label className='col-sm-2 control-label'>SecurityIDSource</label>
                    <div className='col-sm-10'>
                        <PureInput type="text" className='form-control'  disabled field={SecurityIDSource} />
                    </div>
                </div>
                <div className='form-group'>
                    <label className='col-sm-2 control-label'>SecurityID</label>
                    <div className='col-sm-10'>
                        <PureInput type="text" className='form-control'  field={SecurityID} />
                    </div>
                </div>

                <div className='form-group'>
                    <div className='col-sm-offset-2 col-sm-4'>
                        <button type="submit" className='btn btn-default' disabled={submitting}>
                            {submitting ? <i/> : <i/>}Submit
                        </button>
                    </div>
                    <div className='col-sm-6'>
                        <button type="button" className='btn btn-default' disabled={submitting} onClick={resetForm}>Reset</button> <br />
                    </div>
                </div>

            <FixMessage fixMessage={this.props.fixMessage} sendFixMessage={this.props.sendFixMessage}
                        fixMessageResponse={this.props.fixMessageResponse} />
        </form>
            </div>
    }
}
QuoteRequest.propTypes = {
    fields: React.PropTypes. object.isRequired,
    handleSubmit: React.PropTypes.func.isRequired,
    resetForm: React.PropTypes.func.isRequired,
    submitting: React.PropTypes.bool.isRequired,
    fixMessage: React.PropTypes.string.isRequired,
    fixMessageResponse: React.PropTypes.string.isRequired,
    createQuoteRequest: React.PropTypes.func.isRequired,
    cleanFixMessage: React.PropTypes.func.isRequired,
    sendFixMessage: React.PropTypes.func.isRequired
}


export default QuoteRequest = reduxForm({
    form: 'quote',
    fields,
    validate,
    initialValues: {
        MsgType: 'R', QuoteReqID:'', SendingTime:timestamp, ExDestination:'160', NoRelatedSym:'1', SecurityIDSource:4,
        SecurityID:''


    }
})(QuoteRequest)
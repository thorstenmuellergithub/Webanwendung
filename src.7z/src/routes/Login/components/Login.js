import React from 'react'

export default class LoginView extends React.Component {

  constructor (props) {
    super(props)
    this.state = {
      data: {}
    }
  }

  handleChange = (e) => {
    this.state.data[e.target.id] = e.target.value
  }

  handleSubmit = (e) => {
    // Prevent refreshing form upon first submit
    e.preventDefault()

    if (this.refs.form.checkValidity()) {
      this.props.login(this.state.data)
    }
  }

  componentDidMount () {
    // this.props.cleanFixMessage()
  }

  render () {
    return <div>
      <h4>Bitte geben Sie Ihre Konto Nummer ein</h4>
      <form ref='form' className='form-horizontal' onSubmit={this.handleSubmit}>
        <div className='form-group'>
          <label htmlFor='accountNumber' className='col-sm-2 control-label'>Konto</label>
          <div className='col-sm-10'>
            <input type='text' className='form-control' name='accountNumber' id='accountNumber'
              defaultValue={this.props.accountNumber}
              required onChange={this.handleChange} />
          </div>
        </div>
        <div className='form-group'>
          <div className='col-sm-offset-2 col-sm-10'>
            <button type='submit' className='btn btn-default'>Log in</button>
          </div>
        </div>
      </form>
    </div>
  }
}

LoginView.propTypes = {
  login: React.PropTypes.func.isRequired,
  accountNumber: React.PropTypes.string
}

export default LoginView

import { connect } from 'react-redux'
import { createCSIExeRepFixMessage } from '../modules/PostCSI'
import { cleanFixMessage, sendFixMessageToCSI } from 'components/FixMessage/modules/FixMessage'

import PostCSI from '../components/PostCSI'

const mapActionCreators = {
    createCSIExeRepFixMessage,
    cleanFixMessage,
    sendFixMessageToCSI

}

const mapStateToProps = (state) => {
    return {
        fixMessage: state.FixMessage.request,
        fixMessageResponse: state.FixMessage.response
    }
}

export default connect(mapStateToProps, mapActionCreators)(PostCSI)

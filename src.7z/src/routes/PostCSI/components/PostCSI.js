import React from 'react'
import moment from 'moment'
import FixMessage from 'components/FixMessage'
import PureInput from 'components/PureInput'
import { reduxForm, addArrayValue } from 'redux-form'
export const fields = ['BeginString', 'MsgType', 'SenderCompID', 'TargetCompID', 'OnbehalfofCompID', 'DelivertoCompID', 'MsgSeqNum',
    'SenderSubID', 'SenderLocationID', 'TargetSubID', 'TargetLocationID', 'OnBehalfOfSubID', 'OnBehalfOfLocationID', 'DeliverToSubID',
    'DeliverToLocationID', 'SendingTime', 'ApplVerlID', 'PossDupFlag', 'OrigSendingTime', 'MessageEncoding', 'SecondaryClOrdID',
    'TrdMatchID', 'OrderID', 'ClOrdID', 'ExecID', 'SecurityIDSource', 'SecurityID', 'ExecType', 'Side', 'OrderQty', 'Account',
    'Currency', 'LastQty', 'LastPx', 'GrossTradeAmt', 'LastMkt', 'LeavesQty', 'CumQty', 'TransactTime', 'SecondaryOrderID',
    'SettlDate', 'OrderEntryByEmployee', 'ClearingCode', 'PositionType', 'PositionLockDate', 'TradeDate', 'CompensationInd',
    'CompensationSpec', 'CientFrontEndSystem', 'ClientFrontEndSystem', 'ElecTransmission', 'DistributionChannel', 'NumDaysInterest',
    'SettlementLabel', 'SettlInstID', 'CowoLabel', 'ProcessSeparator',
    'parties[].PartyID', 'parties[].PartyIDSource', 'parties[].PartyRole', 'parties[].NoPartySubIDs', 'parties[].PartySubID', 'parties[].PartySubIDType',
    'Condition[].ConditionType', 'Condition[].ConditionAmt', 'Condition[].ConditionAmtType', 'Condition[].ConditionBase', 'Condition[].ConditionCurr',
    'Condition[].ConditionCurrType', 'Condition[].ConditionVATIncluded', 'Condition[].ConditionVATAmt', 'Condition[].ConditionSource', 'Condition[].ConditionLiability',
    'EXEREP[].ExecRefID', 'EXEREP[].ExecCancelationReasonID']

const timestamp = moment().format('YYYYMMDD-HH:mm:ss:SSS')
const validate = values => {
    const errors = {}
    if(!values.BeginString){
        errors.BeginString = 'required'
    }

    if(!values.MsgType){
        errors.MsgType = 'required'
    }
    return errors
}


export default class PostCSI extends React.Component{
    constructor (props){
        super(props)
        this.state = {
            MsgArt: ''
        }
    }

    handleSubmit = (e) => {
        // Prevent refreshing form upon first submit
        //e.preventDefault()
        this.props.cleanFixMessage()
        this.props.createCSIExeRepFixMessage(e)
        }
    componentDidMount () {
        this.props.cleanFixMessage()
    }

    render(){
        const {
            fields: {BeginString, MsgType, SenderCompID, TargetCompID, OnbehalfofCompID, DelivertoCompID, MsgSeqNum,
                SenderSubID, SenderLocationID, TargetSubID, TargetLocationID, OnBehalfOfSubID, OnBehalfOfLocationID, DeliverToSubID,
                DeliverToLocationID, SendingTime, ApplVerlID, PossDupFlag, OrigSendingTime, MessageEncoding, SecondaryClOrdID,
                TrdMatchID, OrderID, ClOrdID, ExecID, SecurityIDSource, SecurityID, ExecType, Side, OrderQty, Account,
                Currency, LastQty, LastPx, GrossTradeAmt, LastMkt, LeavesQty, CumQty, TransactTime, SecondaryOrderID,
                SettlDate, OrderEntryByEmployee, ClearingCode, PositionType, PositionLockDate, TradeDate, CompensationInd,
                CompensationSpec, CientFrontEndSystem, ClientFrontEndSystem, ElecTransmission, DistributionChannel,
                NumDaysInterest, SettlementLabel, SettlInstID, CowoLabel, ProcessSeparator,
                parties, Condition, EXEREP}, handleSubmit, resetForm, submitting
            } = this.props

        return  <form onSubmit={handleSubmit(this.handleSubmit)}>

            <div className='form-group'>
                <label className="col-sm-2 control-labe">Art des Execution Reports</label>
                <div className='col-sm-offset-2 col-sm-10'>
                    <label className='radio-inline'>
                        <input type='radio'
                               checked={this.state.MsgArt === 'EXEREPCAN'} onChange={() => this.setState({MsgArt: 'EXEREPCAN'})} onClick={() =>{if(EXEREP.length<1){ EXEREP.addField()}}} />ExeRepCan</label>
                    <label className='radio-inline'>
                        <input type='radio'
                               checked={this.state.MsgArt === 'NEWEXEREP'} onChange={() => this.setState({MsgArt: 'NEWEXEREP'})} onClick={() => EXEREP.removeField()} />NewExeRep</label>
                </div>


                <br />
                {EXEREP.map((exerep, index) => <div key={index}>
                    <div className='form-group'>
                        <label className='col-sm-2 control-label'>ExecRefID</label>
                        <div className='col-sm-10'>
                            <PureInput type="text" placeholder="ExeRef" field={exerep.ExecRefID} />
                        </div>
                    </div>
                    <div className='form-group'>
                        <label className='col-sm-2 control-label'>ExecCancelationReasonID</label>
                        <div className='col-sm-10'>
                            <PureInput type="text" placeholder="ExeRef" field={exerep.ExecCancelationReasonID} />
                        </div>
                    </div>
                    </div>)}

            </div>

            <div className='form-group'>
                <label className='col-sm-2 control-label'>Begin String</label>
                <div className='col-sm-10'>
                    <input type="text" className='form-control' disabled {...BeginString}  />
                </div>
            </div>
            <div className='form-group'>
                <label className='col-sm-2 control-label'>MsgType</label>
                <div className='col-sm-10'>
                    <input type="text" className='form-control' disabled {...MsgType}  />
                </div>
            </div>
            <div className='form-group'>
                <label className='col-sm-2 control-label'>SenderCompID</label>
                <div className='col-sm-10'>
                    <input type="text" className='form-control' disabled {...SenderCompID}  />
                    {SenderCompID.touched && SenderCompID.error && <span>{SenderCompID.error}</span>}
                </div>
            </div>
            <div className='form-group'>
                <label className='col-sm-2 control-label'>TargetCompID</label>
                <div className='col-sm-10'>
                    <select className='form-control' {...TargetCompID}>
                        <option value='CDP'>Comdirect</option>
                        <option value='CSI'>CSI</option>
                        <option value='CBP'>Host</option>
                    </select>
                </div>
            </div>
            <div className='form-group'>
                <label className='col-sm-2 control-label'>OnbehalfofCompID</label>
                <div className='col-sm-10'>
                    <input type="text" className='form-control' {...OnbehalfofCompID}  />
                </div>
            </div>
            <div className='form-group'>
                <label className='col-sm-2 control-label'>DelivertoCompID</label>
                <div className='col-sm-10'>
                    <input type="text" className='form-control' {...DelivertoCompID}  />
                </div>
            </div>
            <div className='form-group'>
                <label className='col-sm-2 control-label'>MsgSeqNum</label>
                <div className='col-sm-10'>
                    <input type="text" className='form-control' disabled {...MsgSeqNum}  />
                </div>
            </div>
            <div className='form-group'>
                <label className='col-sm-2 control-label'>SenderSubID</label>
                <div className='col-sm-10'>
                    <select className='form-control' {...SenderSubID}>
                        <option value='CDP'>Comdirect</option>
                        <option value='AM'>Auftragsmanager</option>
                    </select>
                </div>
            </div>
            <div className='form-group'>
                <label className='col-sm-2 control-label'>SenderLocationID</label>
                <div className='col-sm-10'>
                    <input type="text" className='form-control' {...SenderLocationID}  />
                </div>
            </div>
            <div className='form-group'>
                <label className='col-sm-2 control-label'>TargetSubID</label>
                <div className='col-sm-10'>
                    <select className='form-control' {...TargetSubID}>
                        <option value='CDP'>Comdirect</option>
                        <option value='AM'>Auftragsmanager</option>
                    </select>
                </div>
            </div>
            <div className='form-group'>
                <label className='col-sm-2 control-label'>TargetLocationID</label>
                <div className='col-sm-10'>
                    <input type="text" className='form-control' {...TargetLocationID}  />
                </div>
            </div>
            <div className='form-group'>
                <label className='col-sm-2 control-label'>OnBehalfOfSubID</label>
                <div className='col-sm-10'>
                    <input type="text" className='form-control' {...OnBehalfOfSubID}  />
                </div>
            </div>
            <div className='form-group'>
                <label className='col-sm-2 control-label'>OnBehalfOfLocationID</label>
                <div className='col-sm-10'>
                    <input type="text" className='form-control' {...OnBehalfOfLocationID}  />
                </div>
            </div>
            <div className='form-group'>
                <label className='col-sm-2 control-label'>DeliverToSubID</label>
                <div className='col-sm-10'>
                    <input type="text" className='form-control' {...DeliverToSubID}  />
                </div>
            </div>
            <div className='form-group'>
                <label className='col-sm-2 control-label'>DeliverToLocationID</label>
                <div className='col-sm-10'>
                    <input type="text" className='form-control' {...DeliverToLocationID}  />
                </div>
            </div>
            <div className='form-group'>
                <label className='col-sm-2 control-label'>ApplVerlID</label>
                <div className='col-sm-10'>
                    <input type="text" className='form-control' disabled {...ApplVerlID}  />
                </div>
            </div>
            <div className='form-group'>
                <label className='col-sm-2 control-label'>PossDupFlag</label>
                <div className='col-sm-10'>
                    <select className='form-control' {...PossDupFlag}>
                        <option value='N'>'N' - Original Nachricht</option>
                        <option value='Y'>'Y' - Duplikat</option>
                    </select>
                </div>
            </div>
            <div className='form-group'>
                <label className='col-sm-2 control-label'>MessageEncoding</label>
                <div className='col-sm-10'>
                    <input type="text" className='form-control' disabled {...MessageEncoding}  />
                </div>
            </div>
            <div className='form-group'>
                <label className='col-sm-2 control-label'>SecondaryClOrdID</label>
                <div className='col-sm-10'>
                    <input type="text" className='form-control' {...SecondaryClOrdID}  />
                </div>
            </div>
            <div className='form-group'>
                <label className='col-sm-2 control-label'>TrdMatchID</label>
                <div className='col-sm-10'>
                    <input type="text" className='form-control' {...TrdMatchID}  />
                </div>
            </div>
            <div className='form-group'>
                <label className='col-sm-2 control-label'>OrderID</label>
                <div className='col-sm-10'>
                    <input type="text" className='form-control' {...OrderID}  />
                </div>
            </div>
            <div className='form-group'>
                <label className='col-sm-2 control-label'>ClOrdID</label>
                <div className='col-sm-10'>
                    <input type="text" className='form-control' {...ClOrdID}  />
                </div>
            </div>
            <div className='form-group'>
                <label className='col-sm-2 control-label'>ExecID</label>
                <div className='col-sm-10'>
                    <input type="text" className='form-control' {...ExecID}  />
                </div>
            </div>
            <div className='form-group'>
                <label className='col-sm-2 control-label'>SecurityIDSource</label>
                <div className='col-sm-10'>
                    <input type="text" className='form-control' {...SecurityIDSource}  />
                </div>
            </div>
            <div className='form-group'>
                <label className='col-sm-2 control-label'>SecurityID</label>
                <div className='col-sm-10'>
                    <input type="text" className='form-control' {...SecurityID}  />
                </div>
            </div>
            <div className='form-group'>
                <label className='col-sm-2 control-label'>ExecType</label>
                <div className='col-sm-10'>
                    <select className='form-control' {...ExecType}>
                        <option value='G'>'G'</option>
                        <option value='H'>'H'</option>
                        <option value='F'>'F'</option>
                        <option value='I'>'I'</option>
                    </select>
                </div>
            </div>
            <div className='form-group'>
                <label className='col-sm-2 control-label'>Side</label>
                <div className='col-sm-10'>
                    <select className='form-control' {...Side}>
                        <option value='1'>'1' - Kauf</option>
                        <option value='2'>'2' - Verkauf</option>
                    </select>
                </div>
            </div>
            <div className='form-group'>
                <label className='col-sm-2 control-label'>OrderQty</label>
                <div className='col-sm-10'>
                    <input type="text" className='form-control' {...OrderQty}  />
                </div>
            </div>
            <div className='form-group'>
                <label className='col-sm-2 control-label'>Account</label>
                <div className='col-sm-10'>
                    <input type="text" className='form-control' disabled {...Account}  />
                </div>
            </div>
            <div className='form-group'>
                <label className='col-sm-2 control-label'>Currency</label>
                <div className='col-sm-10'>
                    <input type="text" className='form-control' {...Currency}  />
                </div>
            </div>
            <div className='form-group'>
                <label className='col-sm-2 control-label'>LastQty</label>
                <div className='col-sm-10'>
                    <input type="text" className='form-control' {...LastQty}  />
                </div>
            </div>
            <div className='form-group'>
                <label className='col-sm-2 control-label'>LastPx</label>
                <div className='col-sm-10'>
                    <input type="text" className='form-control' {...LastPx}  />
                </div>
            </div>
            <div className='form-group'>
                <label className='col-sm-2 control-label'>GrossTradeAmt</label>
                <div className='col-sm-10'>
                    <input type="text" className='form-control' {...GrossTradeAmt}  />
                </div>
            </div>
            <div className='form-group'>
                <label className='col-sm-2 control-label'>LastMkt</label>
                <div className='col-sm-10'>
                    <input type="text" className='form-control' {...LastMkt}  />
                </div>
            </div>
            <div className='form-group'>
                <label className='col-sm-2 control-label'>LeavesQty</label>
                <div className='col-sm-10'>
                    <input type="text" className='form-control' {...LeavesQty}  />
                </div>
            </div>
            <div className='form-group'>
                <label className='col-sm-2 control-label'>CumQty</label>
                <div className='col-sm-10'>
                    <input type="text" className='form-control' {...CumQty}  />
                </div>
            </div>
            <div className='form-group'>
                <label className='col-sm-2 control-label'>SecondaryOrderID</label>
                <div className='col-sm-10'>
                    <input type="text" className='form-control' {...SecondaryOrderID}  />
                </div>
            </div>
            <div className='form-group'>
                <label className='col-sm-2 control-label'>SettlDate</label>
                <div className='col-sm-10'>
                    <input type="text" className='form-control' placeholder="YYYYMMDD" {...SettlDate}  />
                </div>
            </div>
            <div className='form-group'>
                <label className='col-sm-2 control-label'>OrderEntryByEmployee</label>
                <div className='col-sm-10'>
                    <input type="text" className='form-control' {...OrderEntryByEmployee}  />
                </div>
            </div>
            <div className='form-group'>
                <label className='col-sm-2 control-label'>ClearingCode</label>
                <div className='col-sm-10'>
                    <input type="text" className='form-control' {...ClearingCode}  />
                </div>
            </div>
            <div className='form-group'>
                <label className='col-sm-2 control-label'>PositionType</label>
                <div className='col-sm-10'>
                    <input type="text" className='form-control' {...PositionType}  />
                </div>
            </div>
            <div className='form-group'>
                <label className='col-sm-2 control-label'>PositionLockDate</label>
                <div className='col-sm-10'>
                    <input type="text" className='form-control' placeholder="YYYYMMDD" {...PositionLockDate}  />
                </div>
            </div>
            <div className='form-group'>
                <label className='col-sm-2 control-label'>TradeDate</label>
                <div className='col-sm-10'>
                    <input type="text" className='form-control' placeholder="YYYYMMDD" {...TradeDate}  />
                </div>
            </div>
            <div className='form-group'>
                <label className='col-sm-2 control-label'>CompensationInd</label>
                <div className='col-sm-10'>
                    <select className='form-control' {...CompensationInd}>
                        <option value='J'>'J' - Entgelte Rechnen</option>
                        <option value='N'>'N' - Keine Entgelte Rechnen</option>
                    </select>
                </div>
            </div>
            <div className='form-group'>
                <label className='col-sm-2 control-label'>CompensationSpec</label>
                <div className='col-sm-10'>
                    <select className='form-control' {...CompensationSpec}>
                        <option value='J'>'J'</option>
                        <option value='A'>'A' - Alle Entgelte sind zu berechnen</option>
                        <option value='C'>'C' - Nur Courtage, nicht berechnen</option>
                        <option value='M'>'M' - nur manuelle Entelte berücksichtigen</option>
                    </select>
                </div>
            </div>
            <div className='form-group'>
                <label className='col-sm-2 control-label'>CientFrontEndSystem</label>
                <div className='col-sm-10'>
                    <input type="text" className='form-control' disabled {...CientFrontEndSystem}  />
                </div>
            </div>
            <div className='form-group'>
                <label className='col-sm-2 control-label'>ElecTransmission</label>
                <div className='col-sm-10'>
                    <select className='form-control' {...ElecTransmission}>
                        <option value='13'>'13' - comdirect-dezentral (comhome)</option>
                        <option value='14'>'14' - comdirect Backoffice</option>
                        <option value='23'>'23' - comdirect Host</option>
                    </select>
                </div>
            </div>
            <div className='form-group'>
                <label className='col-sm-2 control-label'>DistributionChannel</label>
                <div className='col-sm-10'>
                    <select className='form-control' {...DistributionChannel}>
                        <option value='01'>'01' - Telefon</option>
                        <option value='02'>'02' - Schalter</option>
                        <option value='03'>'03' - Fax</option>
                        <option value='04'>'04' - Internet</option>
                        <option value='09'>'09' - Unbekannt</option>
                    </select>
                </div>
            </div>
            <div className='form-group'>
                <label className='col-sm-2 control-label'>NumDaysInterest</label>
                <div className='col-sm-10'>
                    <input type="text" className='form-control' {...NumDaysInterest}  />
                </div>
            </div>
            <div className='form-group'>
                <label className='col-sm-2 control-label'>SettlementLabel</label>
                <div className='col-sm-10'>
                    <input type="text" className='form-control' {...SettlementLabel}  />
                </div>
            </div>
            <div className='form-group'>
                <label className='col-sm-2 control-label'>SettlInstID</label>
                <div className='col-sm-10'>
                    <input type="text" className='form-control' {...SettlInstID}  />
                </div>
            </div>
            <div className='form-group'>
                <label className='col-sm-2 control-label'>CowoLabel</label>
                <div className='col-sm-10'>
                    <input type="text" className='form-control' {...CowoLabel}  />
                </div>
            </div>
            <div className='form-group'>
                <label className='col-sm-2 control-label'>ProcessSeparator</label>
                <div className='col-sm-10'>
                    <select className='form-control' {...ProcessSeparator}>
                        <option value='0'>'0' - alter Prozess</option>
                        <option value='8'>'8' - neuer Prozess</option>
                    </select>
                </div>
            </div>

            <div className='form-group>'>
                {!parties.length && <label className="col-sm-2 control-label">Keine Parties vorhanden</label>}
                <button type="button" className='btn btn-default' onClick={() => {parties.addField()}}><i/>Auf eine weitere Party gehen</button>
                <button type="button" className='btn btn-default' onClick={() => {parties.removeField()}}><i/>eine Party weniger</button>

                {parties.map((party, index) => <div className='form-group' key={index}>
                    <div className='form-group'>
                        <div className='col-sm-5 GroupID'>
                            <label className='col-sm-2 control-label'>Party #{index +1}</label>
                        </div>
                    </div>
                    <div>
                        <div className='col-sm-10'>
                            <label className='col-sm-2 control-label'>PartyID</label>
                            <div className='col-sm-10'>
                                <PureInput type="text" placeholder="PartyID" field={party.PartyID} />
                            </div>
                        </div>
                        <div className='col-sm-10'>
                            <label className='col-sm-2 control-label'>PartyIDSource</label>
                            <div className='col-sm-10'>
                                <PureInput type="text" placeholder="PartyIDSource" field={party.PartyIDSource} />
                            </div>
                        </div>
                        <div className='col-sm-10'>
                            <label className='col-sm-2 control-label'>PartyRole</label>
                            <div className='col-sm-10'>
                                <PureInput type="text" placeholder="PartyRole" field={party.PartyRole} />
                            </div>
                        </div>
                        <div className='col-sm-10'>
                            <label className='col-sm-2 control-label'>NoPartySubIDs</label>
                            <div className='col-sm-10'>
                                <PureInput type="text" placeholder="1" field={party.NoPartySubIDs} />
                            </div>
                        </div>
                        <div className='col-sm-10'>
                            <label className='col-sm-2 control-label'>PartySubID</label>
                            <div className='col-sm-10'>
                                <PureInput type="text" placeholder="PartySubID" field={party.PartySubID} />
                            </div>
                        </div>
                        <div className='col-sm-10'>
                            <label className='col-sm-2 control-label'>PartySubIDType</label>
                            <div className='col-sm-10'>
                                <PureInput type="text" placeholder="PartySubIDType" field={party.PartySubIDType} />
                            </div>
                        </div>
                    </div>
                </div>)}
            </div>
<div className="form-group col-sm-10">

            <div className='form-group>'>
                {!Condition.length && <label className="col-sm-2 control-label">Keine Konditionengruppe vorhanden</label>}
                <button type="button" className='btn btn-default' onClick={() => {Condition.addField()}}><i/>eine weitere Konditionengruppe</button>
                <button type="button" className='btn btn-default' onClick={() => {Condition.removeField()}}><i/>eine Konditionengruppe weniger</button>

                {Condition.map((condition, index) => <div className='form-group' key={index}>
                    <div className='form-group'>
                        <div className='col-sm-5 GroupID'>
                            <label className='col-sm-2 control-label'>Konditionengruppe #{index +1}</label>
                        </div>
                    </div>
                    <div>
                        <div>
                        <div className='col-sm10'>
                            <label className='col-sm-2 control-label'>ConditionType</label>
                            <div className='col-sm-10'>
                                <PureInput type="text" placeholder="ConditionType" field={condition.ConditionType} />
                            </div>
                        </div>
                            </div>
                        <div className='col-sm-10'>
                            <label className='col-sm-2 control-label'>ConditionAmt</label>
                            <div className='col-sm-10'>
                                <PureInput type="text" placeholder="ConditionAmt" field={condition.ConditionAmt} />
                            </div>
                        </div>
                        <div className='col-sm-10'>
                            <label className='col-sm-2 control-label'>ConditionAmtType</label>
                            <div className='col-sm-10'>
                                <PureInput type="text" placeholder="ConditionAmtType" field={condition.ConditionAmtType} />
                            </div>
                        </div>
                        <div className='col-sm-10'>
                            <label className='col-sm-2 control-label'>ConditionBase</label>
                            <div className='col-sm-10'>
                                <PureInput type="text" placeholder="ConditionBase" field={condition.ConditionBase} />
                            </div>
                        </div>
                        <div className='col-sm-10'>
                            <label className='col-sm-2 control-label'>ConditionCurr</label>
                            <div className='col-sm-10'>
                                <PureInput type="text" placeholder="ConditionCurr" field={condition.ConditionCurr} />
                            </div>
                        </div>
                        <div className='col-sm-10'>
                            <label className='col-sm-2 control-label'>ConditionCurrType</label>
                            <div className='col-sm-10'>
                                <PureInput type="text" placeholder="ConditionCurrType" field={condition.ConditionCurrType} />
                            </div>
                        </div>
                        <div className='col-sm-10'>
                            <label className='col-sm-2 control-label'>ConditionVATIncluded</label>
                            <div className='col-sm-10'>
                                <PureInput type="text" placeholder="ConditionVATIncluded" field={condition.ConditionVATIncluded} />
                            </div>
                        </div>
                        <div className='col-sm-10'>
                            <label className='col-sm-2 control-label'>ConditionVATAmt</label>
                            <div className='col-sm-10'>
                                <PureInput type="text" placeholder="ConditionVATAmt" field={condition.ConditionVATAmt} />
                            </div>
                        </div>
                        <div className='col-sm-10'>
                            <label className='col-sm-2 control-label'>ConditionSource</label>
                            <div className='col-sm-10'>
                                <PureInput type="text" placeholder="ConditionLiability" field={condition.ConditionSource} />
                            </div>
                        </div>
                        <div className='col-sm-10'>
                            <label className='col-sm-2 control-label'>ConditionLiability</label>
                            <div className='col-sm-10'>
                                <PureInput type="text" placeholder="ConditionCurr" field={condition.ConditionLiability} />
                            </div>
                        </div>
                    </div>
                </div>)}
            </div>
</div>

            <div className="form-group col-sm-10">
            <div className='form-group'>
                <div className='col-sm-offset-2 col-sm-4'>
                    <button type="submit" className='btn btn-default'  disabled={submitting}>
                        {submitting ? <i/> : <i/>}Submit
                    </button>
                </div>
                <div className='col-sm-6'>
                    <button type="button" className='btn btn-default'  disabled={submitting} onClick={resetForm}>Reset</button>
                </div>
            </div>

                <FixMessage fixMessage={this.props.fixMessage} sendFixMessage={this.props.sendFixMessageToCSI}
            fixMessageResponse={this.props.fixMessageResponse} />

        </div>
        </form>
    }
}
PostCSI.propTypes = {
    fields: React.PropTypes. object.isRequired,
    handleSubmit: React.PropTypes.func.isRequired,
    resetForm: React.PropTypes.func.isRequired,
    submitting: React.PropTypes.bool.isRequired,
    fixMessage: React.PropTypes.string.isRequired,
    fixMessageResponse: React.PropTypes.string.isRequired,
    createCSIExeRepFixMessage: React.PropTypes.func.isRequired,
    cleanFixMessage: React.PropTypes.func.isRequired,
    sendFisMessageToCSI: React.PropTypes.func.isRequired

}



export default PostCSI = reduxForm({
    form: 'csi',
    fields,
    validate,
    initialValues: {
        BeginString: 'FIXT1.1', MsgType: '8', SenderCompID: 'DECIDE', MsgSeqNum: '0', TargetCompID: 'CDP',
        OnbehalfofCompID: '', DelivertoCompID: '', SenderSubID:'CDP', SenderLocationID: '', TargetSubID: 'CDP',
        TargetLocationID: '', OnBehalfOfSubID:'', OnBehalfOfLocationID:'', DeliverToSubID:'', DeliverToLocationID:'',
        SendingTime: timestamp, ApplVerlID: '9', PossDupFlag:'N', OrigSendingTime: timestamp, MessageEncoding:'UTF-8',
        SecondaryClOrdID: '', TrdMatchID: '', OrderID:'', ClOrdID:'', ExecID:'', SecurityIDSource:'', SecurityID:'',
        ExecType: 'G', Side:'1', OrderQty:'', Account:'', Currency:'', LastQty:'', LastPx:'', GrossTradeAmt:'', LastMkt:'',
        LeavesQty:'', CumQty:'', TransactTime:timestamp, SecondaryOrderID:'', SettlDate:'', OrderEntryByEmployee:'',
        ClearingCode: '', PositionType:'', PositionLockDate:'', TradeDate:'', CompensationInd:'', CompensationSpec:'',
        CientFrontEndSystem:'CD_CORONA', ClientFrontEndSystem:timestamp, ElecTransmission:'13', DistributionChannel:'01',
        NumDaysInterest: '', SettlementLabel:'', SettlInstID:'', CowoLabel: '', ProcessSeparator:'8'


    }
})(PostCSI)
import {CREATE_CSI_EXE_REP_FIX_MESSAGE} from 'components/FixMessage/modules/FixMessage'
// ------------------------------------
// Constants
// ------------------------------------

// ------------------------------------
// Actions
// ------------------------------------
export function createCSIExeRepFixMessage (data) {
    return (dispatch, getState) => {
        dispatch({
            type: CREATE_CSI_EXE_REP_FIX_MESSAGE,
            payload: data
        })
    }
}

export const actions = {
    createCSIExeRepFixMessage
}


// ------------------------------------
// Action Handlers
// ------------------------------------
const ACTION_HANDLERS = {
    [CREATE_CSI_EXE_REP_FIX_MESSAGE]: (state, action) => {
        return action.payload
    }
}

// ------------------------------------
// Reducer
// ------------------------------------
const initialState = 0
export default function postCSIReducer (state = initialState, action) {
    const handler = ACTION_HANDLERS[action.type]

    return handler ? handler(state, action) : state
}
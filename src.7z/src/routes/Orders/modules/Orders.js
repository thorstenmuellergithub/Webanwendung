import { callFix, createFixMessage, SOH_DELIMITER } from 'store/common/rest'
import FixMapping from 'store/common/FixMapping'

// ------------------------------------
// Constants
// ------------------------------------
export const SEARCH_ORDERS_REQUEST = 'SEARCH_ORDERS_REQUEST'
export const SEARCH_ORDERS_RESPONSE = 'SEARCH_ORDERS_RESPONSE'
export const SEARCH_ORDERS_FAILURE = 'SEARCH_ORDERS_FAILURE'

// ------------------------------------
// Actions
// ------------------------------------

export function searchOrders (data) {
  /* eslint-disable max-len */
  let template = ''

  if (data.orderId && data.orderId !== '') {
    template = '8=FIXT.1.1^A9=464^A35=H^A49=CDPHTTP^A56=DECIDE^A34=1^A11={orderId}^A1={accountNumber}^A52=20160610-14:07:03^A'
  } else {
    template = '8=FIXT.1.1^A9=464^A35=AF^A49=CDPHTTP^A56=DECIDE^A34=1^A1={accountNumber}^A584=ABC123^A585=7^A52=20160610-14:07:03^A'
  }
  /* eslint-enable max-len */
  const fixMessage = createFixMessage(template, data)

  return callFix(fixMessage, SEARCH_ORDERS_REQUEST, SEARCH_ORDERS_RESPONSE, SEARCH_ORDERS_FAILURE)
}

export const actions = {
  searchOrders
}

export function mapSearchResponse (state, action) {
  const response = action.payload
  let columns = []
  // split response by messages
  let rows = response.split('8=FIX').map((rowText) => {
    return rowText.split(SOH_DELIMITER)
  })
  // remove first element, it is empty string
  rows.shift()
  rows = rows.map((row, rowIndex) => {
    const mappedRow = {}
    row.forEach((property) => {
      const splitProperty = property.split('=')
      if (splitProperty[0] !== '' && FixMapping[splitProperty[0]]) {
        // map rows via mapping
        const propertyName = FixMapping[splitProperty[0]]

        if (propertyName) {
          mappedRow[propertyName] = splitProperty[1]
        }

        if (columns.indexOf(propertyName) === -1) {
          columns.push(propertyName)
        }
      }
    })
    mappedRow.index = rowIndex
    return mappedRow
  })

  return Object.assign({}, state, {
    rows: rows,
    columns: columns
  })
}

// ------------------------------------
// Action Handlers
// ------------------------------------
const ACTION_HANDLERS = {
  [SEARCH_ORDERS_RESPONSE]: mapSearchResponse
}

// ------------------------------------
// Reducer
// ------------------------------------
const initialState = {
  rows: [],
  columns: []
}

export default function createOrderReducer (state = initialState, action) {
  const handler = ACTION_HANDLERS[action.type]

  return handler ? handler(state, action) : state
}

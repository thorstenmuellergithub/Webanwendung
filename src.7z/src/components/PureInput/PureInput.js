import React from 'react'

class PureInput extends React.Component {
    shouldComponentUpdate(nextProps){
        return this.props.field !== nextProps.field
    }

    render () {
        const {field, ...rest} = this.props
        return <input {...field} {...rest} />
    }
}

PureInput.propTypes = {
    field: React.PropTypes.object.isRequired
}

export default PureInput
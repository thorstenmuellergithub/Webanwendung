import PureInput from './PureInput'

export default PureInput
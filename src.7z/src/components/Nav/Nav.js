import React from 'react'
import { Link } from 'react-router'
import classes from './Nav.scss'

export const Nav = () => (
  <div>
    <ul className='nav nav-pills nav-stacked'>
      <li role='presentation'>
        <Link to='/orders' activeClassName={classes.activeRoute}>
          <span className={classes.linkPrefix}>&gt;</span>Order anzeigen
        </Link>
      </li>
      <li role='presentation'>
        <Link to='/createOrder' activeClassName={classes.activeRoute}>
          <span className={classes.linkPrefix}>&gt;</span>Order erstellen
        </Link>
      </li>
      <li role='presentation'>
        <Link to='/cancelOrder' activeClassName={classes.activeRoute}>
          <span className={classes.linkPrefix}>&gt;</span>Order stornieren
        </Link>
      </li>
<li role='presentation'>
    <Link to='/postCSI' activeClassName={classes.activeRoute}>
<span className={classes.linkPrefix}>&gt;</span>postCSI
</Link>
</li>
      <li role='presentation'>
        <Link to='/QuoteRequest' activeClassName={classes.activeRoute}>
          <span className={classes.linkPrefix}>&gt;</span>Quote Request
        </Link>
      </li>
    </ul>
  </div>

  /* <a class='navbar-brand' href='#'>
    <img alt='Brand' src='...' >
  </a>*/
/*
  <div>
    <h1>WPP Integration Layer Order WebService Demo</h1>
    <Link to='/orders' activeClassName={classes.activeRoute}>
      Orders
    </Link>
    {' · '}
    <Link to='/createOrder' activeClassName={classes.activeRoute}>
      Order erstellen
    </Link>
    {' · '}
    <Link to='/cancelOrder' activeClassName={classes.activeRoute}>
      Order abbrechen
    </Link>
  </div>
  */
)

export default Nav

import React from 'react'

export default class FixMessage extends React.Component {

  constructor (props) {
    super(props)
    this.state = {
      fixMessage: props.fixMessage
    }
  }

  componentWillReceiveProps (nextProps) {
    this.setState({
      fixMessage: nextProps.fixMessage
    })
  }

  sendFixMessage = () => {
    this.props.sendFixMessage(this.state.fixMessage)
  }

  handleChange = (e) => {
    this.setState({
      fixMessage: e.target.value
    })
  }

  render () {
    if (this.state.fixMessage) {
      let messageResponse = null
      if (this.props.fixMessageResponse) {
        messageResponse = <div className='form-group'>
          <label htmlFor='fixResponse' className='col-sm-2 control-label'>Antwort</label>
          <div className='col-sm-10'>
            <textarea id='fixResponse' name='fixResponse'
              className='form-control' rows='3' value={this.props.fixMessageResponse} readOnly></textarea>
          </div>
        </div>
      }

      return <div>
        <h4>FIX Nachricht</h4>
        <form ref='form' className='form-horizontal' >
          <div className='form-group'>
            <label htmlFor='fixRequest' className='col-sm-2 control-label'>Nachricht</label>
            <div className='col-sm-10'>
              <textarea id='fixRequest' name='fixRequest'
                className='form-control' rows='3' value={this.state.fixMessage}
                required
                onChange={this.handleChange}></textarea>
            </div>
          </div>
          <div className='form-group'>
            <div className='col-sm-offset-2 col-sm-10'>

              <button className='btn btn-default' onClick={this.sendFixMessage} type='button'>Versenden</button>
            </div>
          </div>
          {messageResponse}
        </form>
      </div>
    }
    return null
  }
}

FixMessage.propTypes = {
  fixMessage: React.PropTypes.string.isRequired,
  fixMessageResponse: React.PropTypes.string,
  sendFixMessage: React.PropTypes.func,
  sendFixMessageToCSI: React.PropTypes.func
}

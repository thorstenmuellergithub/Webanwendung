import { callFix, createFixMessage } from 'store/common/rest'

// ------------------------------------
// Constants
// ------------------------------------
export const CLEAN_FIX_MESSAGE = 'CLEAN_FIX_MESSAGE'
export const SET_FIX_MESSAGE = 'SET_FIX_MESSAGE'
export const SEND_FIX_MESSAGE = 'SEND_FIX_MESSAGE'
export const SEND_FIX_MESSAGE_REQUEST = 'SEND_FIX_MESSAGE_REQUEST'
export const SEND_FIX_MESSAGE_SUCCESS = 'SEND_FIX_MESSAGE_SUCCESS'
export const SEND_FIX_MESSAGE_FAILURE = 'SEND_FIX_MESSAGE_FAILURE'

export const CANCEL_ORDER_FIX_MESSAGE = 'CANCEL_ORDER_FIX_MESSAGE'
export const CREATE_ORDER_FIX_MESSAGE = 'CREATE_ORDER_FIX_MESSAGE'

export const CREATE_CSI_EXE_REP_FIX_MESSAGE = 'CREATE_CSI_EXE_REP_FIX_MESSAGE'

export const CREATE_QUOTE_REQUEST_FIX_MESSAGE = 'CREATE_QUOTE_REQUEST_FIX_MESSAGE'


// ------------------------------------
// Actions
// ------------------------------------
export function cleanFixMessage (data) {
  return {
    type: CLEAN_FIX_MESSAGE
  }
}

export function sendFixMessage (data) {
  return (dispatch) => {
    dispatch({
      type: SET_FIX_MESSAGE,
      payload: data
    })
    dispatch(callFix(data, SEND_FIX_MESSAGE_REQUEST, SEND_FIX_MESSAGE_SUCCESS, SEND_FIX_MESSAGE_FAILURE))
  }
}

const initialState = {
  request: '',
  response: ''
}

// ------------------------------------
// Action Handlers
// ------------------------------------
const ACTION_HANDLERS = {
  [CLEAN_FIX_MESSAGE]: (state, action) => {
    return Object.assign({}, initialState)
  },
  [CREATE_CSI_EXE_REP_FIX_MESSAGE]: (state, action) => {
    let template = '8={BeginString}35={MsgType}49={SenderCompID}56={TargetCompID}115={OnbehalfofCompID}128={DelivertoCompID}' +
        '34={MsgSeqNum}50={SenderSubID}142={SenderLocationID}57={TargetSubID}143={TargetLocationID}116={OnBehalfOfSubID}' +
        '144={OnBehalfOfLocationID}129={DeliverToSubID}145={DeliverToLocationID}52={SendingTime}1128={ApplVerlID}43={PossDupFlag}' +
        '122={OrigSendingTime}347={MessageEncoding}526={SecondaryClOrdID}880={TrdMatchID}37={OrderID}11={ClOrdID}' +
        '17={ExecID}22={SecurityIDSource}48={SecurityID}150={ExecType}54={Side}38={OrderQty}1={Account}15={Currency}' +
        '32={LastQty}31={LastPx}381={GrossTradeAmt}30={LastMkt}151={LeavesQty}14={CumQty}60={TransactTime}198={SecondaryOrderID}' +
        '64={SettlDate}38009={OrderEntryByEmployee}38018={ClearingCode}38005={PositionType}38010={PositionLockDate}' +
        '75={TradeDate}38027={CompensationInd}38055={CompensationSpec}'

    if(action.payload.parties.length !== 0) {
      template += '453='+ action.payload.parties.length
      action.payload.parties.map((party) => {
        template += '448=' + party.PartyID
        template += '447=' + party.PartyIDSource
        template += '452=' + party.PartyRole
        template += '802=' + party.NoPartySubIDs
        template += '523=' + party.PartySubID
        template += '803=' + party.PartySubIDType
      })
    }
    if(action.payload.Condition.length !== 0) {
      template += '453='+ action.payload.Condition.length
      action.payload.Condition.map((condition) => {
        template += '38065=' + condition.ConditionType
        template += '38066=' + condition.ConditionAmt
        template += '38028=' + condition.ConditionAmtType
        template += '38015=' + condition.ConditionBase
        template += '38067=' + condition.ConditionCurr
        template += '38049=' + condition.ConditionCurrType
        template += '38016=' + condition.ConditionVATIncluded
        template += '38017=' + condition.ConditionVATAmt
        template += '38014=' + condition.ConditionSource
        template += '38019=' + condition.ConditionLiability
      })
    }

    if(action.payload.EXEREP.length !== 0) {
      action.payload.EXEREP.map((exerep) => {
        template += '19=' + exerep.ExecRefID
        template += '38012=' + exerep.ExecCancelationReasonID
      })
    }
    const fixMessage =createFixMessage (template, action.payload)

    return Object.assign({}, state, {
      request: fixMessage
    })
  },
  [CREATE_QUOTE_REQUEST_FIX_MESSAGE]: (state, action) => {
    const templateData = Object.assign({}, action.payload)

    let template ='35={MsgType}131={QuoteReqID}52={SendingTime}100={ExDestination}146={NoRelatedSym}' +
        '22={SecurityIDSource}48={SecurityID}'

    const fixMessage = createFixMessage (template, action.payload)
    return Object.assign({}, state, {request:fixMessage})
  },
  [CREATE_ORDER_FIX_MESSAGE]: (state, action) => {
    const templateData = Object.assign({}, action.payload)
    if (templateData.orderType === '1') {
      templateData.price = ''
    } else {
      templateData.price = `44=${templateData.price}`
    }

    /* eslint-disable max-len */
    let template = '8=FIXT.1.19=39735=D34=049=CDP52=20160601-13:59:24.08756=DECIDE1128=91={accountNumber}' +
        '11={orderId}15=EUR21=122=438={quantity}40={orderType}{price}48={isin}54={type}55={isin}59={timeInForce}' +
        '60=20160615-13:59:23.900100=160423=2432={expireDate}1133=D38005=0000038008=793138018=00438020=8' +
        '38026=20160615-13:59:24.08738031=CORONA38056=1338057=04453=1448=118200001600447=D452=83802=1523=EUR803=401710=051'
    /* eslint-enable max-len */
    const fixMessage = createFixMessage(template, templateData)

    return Object.assign({}, state, {
      request: fixMessage
    })
  },
  [CANCEL_ORDER_FIX_MESSAGE]: (state, action) => {
    /* eslint-disable max-len */
    let template = '35=F^A11={increasedOrderId}^A41={orderId}^A60=20160610-14:07:03.000'
    /* eslint-enable max-len */
    const fixMessage = createFixMessage(template, action.payload)

    return Object.assign({}, state, {
      request: fixMessage
    })
  },
  [SET_FIX_MESSAGE]: (state, action) => {
    return Object.assign({}, state, {
      request: action.payload
    })
  },
  [SEND_FIX_MESSAGE_FAILURE]: (state, action) => {
    return Object.assign({}, state, {
      response: action.payload.message
    })
  },
  [SEND_FIX_MESSAGE_SUCCESS]: (state, action) => {
    return Object.assign({}, state, {
      response: action.payload
    })
  }
}

// ------------------------------------
// Reducer
// ------------------------------------

export default function fixMessageReducer (state = initialState, action) {
  const handler = ACTION_HANDLERS[action.type]

  return handler ? handler(state, action) : state
}
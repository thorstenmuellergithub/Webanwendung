import React from 'react'
import classes from './AccountNumber.scss'

export default class AccountNumber extends React.Component {

  render () {
    if (this.props.accountNumber && this.props.accountNumber !== '') {
      return <div className={classes.accountNumber}>
        Konto: {this.props.accountNumber}
      </div>
    }
    return null
  }
}

AccountNumber.propTypes = {
  accountNumber: React.PropTypes.string
}

import {
  CALL_API
} from 'redux-api-middleware'

export function textResponse (action, state, res) {
  return res.text()
}

export function callFix (data, requestAction, responseAction, failureAction) {
  return {
    [CALL_API]: {
      endpoint: '/rest/CBNWPPRestConnection.Interface.provideOrderMassStatusRequest',
      method: 'POST',
      body: data,
      headers: {
        'Authorization': 'Basic VFVTRVI6VFVTRVI='
      },
      types: [requestAction, {
        type: responseAction,
        payload: textResponse
      }, failureAction]
    }
  }
}
//another Ednpoint
export function callFixCSI (data, requestAction, responseAction, failureAction) {
  return {
    [CALL_API]: {
      endpoint: '/rest/CBNWPPRestConnection.Interface.provideExecutionReport',
      method: 'POST',
      body: data,
      headers: {
        'Authorization': 'Basic VFVTRVI6VFVTRVI='
      },
      types: [requestAction, {
        type: responseAction,
        payload: textResponse
      }, failureAction]
    }
  }
}

export const SOH_DELIMITER = String.fromCharCode(1)

export function createFixMessage (tmpl, data) {
  let fixMessage = tmpl.replace(/\^A/g, SOH_DELIMITER)
  const dataKeys = Object.keys(data)
  for (let index = 0; index < dataKeys.length; index++) {
    const key = dataKeys[index]
    fixMessage = fixMessage.replace(new RegExp(`\{${key}\}`, 'g'), data[key])
  }
  return fixMessage
}

import React from 'react'
import Header from '../../components/Header'
import Nav from '../../components/Nav'
import classes from './CoreLayout.scss'
import '../../styles/core.scss'

export const CoreLayout = ({ children }) => (
  <div>
    <Header />
    <div className='container-fluid'>
      <div className='col-md-2' >
        <Nav />
      </div>
      <div className='col-md-10' >
        <div className={classes.mainContainer}>
          {children}
        </div>
      </div>
    </div>
  </div>
)

CoreLayout.propTypes = {
  children: React.PropTypes.element.isRequired
}

export default CoreLayout

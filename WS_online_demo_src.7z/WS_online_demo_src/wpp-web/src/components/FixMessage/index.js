import FixMessage from './FixMessage'

export default FixMessage

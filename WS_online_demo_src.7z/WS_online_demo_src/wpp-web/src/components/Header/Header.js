import React from 'react'
import ComnetImage from './assets/comnet_portalname.png'
import CommerzbankImage from './assets/commerzbank_logo.png'
import AccountNumber from 'components/AccountNumber'

export const Header = () => (
  <nav className='navbar navbar-default navbar-static-top'>
    <div className='container-fluid'>
      <span className='navbar-brand'>
        <img alt='Comnet' src={ComnetImage} />
      </span>
      <span className='navbar-brand navbar-right'>
        <img alt='Commerzbank' src={CommerzbankImage} />
      </span>
    </div>
    <AccountNumber />
  </nav>
)

export default Header

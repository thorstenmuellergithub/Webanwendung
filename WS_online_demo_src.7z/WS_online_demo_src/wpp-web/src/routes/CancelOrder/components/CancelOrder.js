import React from 'react'
import FixMessage from 'components/FixMessage'

export default class CancelOrder extends React.Component {

  constructor (props) {
    super(props)

    let orderId = ''
    if (this.props.location.query && this.props.location.query.orderId) {
      orderId = this.props.location.query.orderId
    }

    this.state = {
      data: {
        orderId: orderId
      }
    }
  }

  handleChange = (e) => {
    this.state.data[e.target.id] = e.target.value
  }

  handleSubmit = (e) => {
    // Prevent refreshing form upon first submit
    e.preventDefault()

    if (this.refs.form.checkValidity()) {
      this.props.cancelOrderFixMessage(this.state.data)
    }
  }

  componentDidMount () {
    this.props.cleanFixMessage()
  }

  render () {
    return <div>
      <h4>Order stornieren</h4>
      <form ref='form' className='form-horizontal' onSubmit={this.handleSubmit}>
        <div className='form-group'>
          <label htmlFor='orderId' className='col-sm-2 control-label'>Order ID</label>
          <div className='col-sm-10'>
            <input type='text' className='form-control' name='orderId'
              id='orderId' required onChange={this.handleChange} defaultValue={this.state.data.orderId} />
          </div>
        </div>
        <div className='form-group'>
          <div className='col-sm-offset-2 col-sm-10'>
            <button type='submit' className='btn btn-default'>FIX Nachricht Erstellen</button>
          </div>
        </div>
      </form>
      <FixMessage {...this.props} />
    </div>
  }
}

CancelOrder.propTypes = {
  location: React.PropTypes.object.isRequired,
  cancelOrderFixMessage: React.PropTypes.func.isRequired,
  cleanFixMessage: React.PropTypes.func.isRequired,
  fixMessage: React.PropTypes.string.isRequired
}

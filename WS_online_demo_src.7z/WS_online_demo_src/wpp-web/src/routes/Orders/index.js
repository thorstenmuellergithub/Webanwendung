import { injectReducer } from '../../store/reducers'

// Sync route definition
export default (store) => ({
  path: 'orders',
  getComponent (nextState, cb) {
    /*  Webpack - use 'require.ensure' to create a split point
        and embed an async module loader (jsonp) when bundling   */
    require.ensure([], (require) => {
      /*  Webpack - use require callback to define
          dependencies for bundling   */
      const Counter = require('./containers/OrdersContainer').default

      const reducer = require('./modules/Orders').default

      injectReducer(store, { key: 'Orders', reducer })

      /*  Return getComponent   */
      cb(null, Counter)

    /* Webpack named bundle   */
    }, 'orders')
  }
})

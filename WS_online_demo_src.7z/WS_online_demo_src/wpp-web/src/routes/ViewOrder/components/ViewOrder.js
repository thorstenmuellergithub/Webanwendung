import React from 'react'
import {BootstrapTable, TableHeaderColumn} from 'react-bootstrap-table'
import { Link } from 'react-router'

export default class ViewOrder extends React.Component {

  componentDidMount () {
    this.props.searchOrders({
      orderId: this.props.params.orderId,
      accountNumber: this.props.accountNumber
    })
  }

  getOrderTable = () => {
    if (this.props.orderRows.length > 0) {
      return <BootstrapTable data={this.props.orderRows}
        height='300'
        striped hover condensed bordered={false} keyField='key'>
        <TableHeaderColumn dataField='key' width='300'>Feld Name</TableHeaderColumn>
        <TableHeaderColumn dataField='value' width='300'>Feld Wert</TableHeaderColumn>
      </BootstrapTable>
    }
    return null
  }

  render () {
    let orderTable = this.getOrderTable()

    const cancelOrderLink = `cancelOrder?orderId=${this.props.params.orderId}`

    return <div>
      <h4>Order {this.props.params.orderId}</h4>
      <Link to={cancelOrderLink} title='Order abbrechen' >
        <span className='glyphicon glyphicon-remove' />&nbsp;
        Order {this.props.params.orderId} stornieren</Link>
      {orderTable}
    </div>
  }
}

ViewOrder.propTypes = {
  params: React.PropTypes.object.isRequired,
  searchOrders: React.PropTypes.func.isRequired,
  orderRows: React.PropTypes.array.isRequired,
  accountNumber: React.PropTypes.string.isRequired
}

package wpp;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import org.apache.commons.io.IOUtils;

public class SampleTest {

	
	public static void main(String[] args) {
		File input = new File("message.txt");
		String inputMessage = "";
		try (FileReader reader = new FileReader(input)) {
			inputMessage = IOUtils.toString(reader);
			
			System.out.println(inputMessage.replaceAll("\\^A", String.valueOf(0x01)));
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
}

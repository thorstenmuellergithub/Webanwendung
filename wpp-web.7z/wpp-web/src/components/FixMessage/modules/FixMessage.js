import { callFix, createFixMessage } from 'store/common/rest'

// ------------------------------------
// Constants
// ------------------------------------
export const CLEAN_FIX_MESSAGE = 'CLEAN_FIX_MESSAGE'
export const SET_FIX_MESSAGE = 'SET_FIX_MESSAGE'
export const SEND_FIX_MESSAGE = 'SEND_FIX_MESSAGE'
export const SEND_FIX_MESSAGE_REQUEST = 'SEND_FIX_MESSAGE_REQUEST'
export const SEND_FIX_MESSAGE_SUCCESS = 'SEND_FIX_MESSAGE_SUCCESS'
export const SEND_FIX_MESSAGE_FAILURE = 'SEND_FIX_MESSAGE_FAILURE'

export const CANCEL_ORDER_FIX_MESSAGE = 'CANCEL_ORDER_FIX_MESSAGE'
export const CREATE_ORDER_FIX_MESSAGE = 'CREATE_ORDER_FIX_MESSAGE'

// ------------------------------------
// Actions
// ------------------------------------
export function cleanFixMessage (data) {
  return {
    type: CLEAN_FIX_MESSAGE
  }
}

export function sendFixMessage (data) {
  return (dispatch) => {
    dispatch({
      type: SET_FIX_MESSAGE,
      payload: data
    })
    dispatch(callFix(data, SEND_FIX_MESSAGE_REQUEST, SEND_FIX_MESSAGE_SUCCESS, SEND_FIX_MESSAGE_FAILURE))
  }
}

const initialState = {
  request: '',
  response: ''
}

// ------------------------------------
// Action Handlers
// ------------------------------------
const ACTION_HANDLERS = {
  [CLEAN_FIX_MESSAGE]: (state, action) => {
    return Object.assign({}, initialState)
  },
  [CREATE_ORDER_FIX_MESSAGE]: (state, action) => {
    const templateData = Object.assign({}, action.payload)
    if (templateData.orderType === '1') {
      templateData.price = ''
    } else {
      templateData.price = `44=${templateData.price}`
    }

    /* eslint-disable max-len */
    let template = '8=FIXT.1.19=39735=D34=049=CDP52=20160601-13:59:24.08756=DECIDE1128=91={accountNumber}11={orderId}15=EUR21=122=438={quantity}40={orderType}{price}48={isin}54={type}55={isin}59={timeInForce}60=20160615-13:59:23.900100=160423=2432={expireDate}1133=D38005=0000038008=793138018=00438020=838026=20160615-13:59:24.08738031=CORONA38056=1338057=04453=1448=118200001600447=D452=83802=1523=EUR803=401710=051'
    /* eslint-enable max-len */
    const fixMessage = createFixMessage(template, templateData)

    return Object.assign({}, state, {
      request: fixMessage
    })
  },
  [CANCEL_ORDER_FIX_MESSAGE]: (state, action) => {
    /* eslint-disable max-len */
    let template = '35=F^A11={increasedOrderId}^A41={orderId}^A60=20160610-14:07:03.000'
    /* eslint-enable max-len */
    const fixMessage = createFixMessage(template, action.payload)

    return Object.assign({}, state, {
      request: fixMessage
    })
  },
  [SET_FIX_MESSAGE]: (state, action) => {
    return Object.assign({}, state, {
      request: action.payload
    })
  },
  [SEND_FIX_MESSAGE_FAILURE]: (state, action) => {
    return Object.assign({}, state, {
      response: action.payload.message
    })
  },
  [SEND_FIX_MESSAGE_SUCCESS]: (state, action) => {
    return Object.assign({}, state, {
      response: action.payload
    })
  }
}

// ------------------------------------
// Reducer
// ------------------------------------

export default function fixMessageReducer (state = initialState, action) {
  const handler = ACTION_HANDLERS[action.type]

  return handler ? handler(state, action) : state
}

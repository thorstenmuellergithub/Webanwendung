import { CANCEL_ORDER_FIX_MESSAGE } from 'components/FixMessage/modules/FixMessage'
// ------------------------------------
// Constants
// ------------------------------------

// ------------------------------------
// Actions
// ------------------------------------
export function cancelOrderFixMessage (data) {
  const dataCopy = Object.assign({}, data)
  const orderId = data.orderId
  if (orderId.match(/.*:\d*/)) {
    const orderIdSuffix = parseInt(orderId.replace(/.*:(\d*)/, '$1')) + 1 + ''
    const increasedOrderId = orderId.substring(0, orderId.length - orderIdSuffix.length) + orderIdSuffix
    dataCopy.increasedOrderId = increasedOrderId
  } else {
    dataCopy.increasedOrderId = orderId
  }

  return {
    type: CANCEL_ORDER_FIX_MESSAGE,
    payload: dataCopy
  }
}

export const actions = {
  cancelOrderFixMessage
}

// ------------------------------------
// Action Handlers
// ------------------------------------
const ACTION_HANDLERS = {
  [CANCEL_ORDER_FIX_MESSAGE]: (state, action) => {
    return action.payload
  }
}

// ------------------------------------
// Reducer
// ------------------------------------
const initialState = 0
export default function createOrderReducer (state = initialState, action) {
  const handler = ACTION_HANDLERS[action.type]

  return handler ? handler(state, action) : state
}

import { injectReducer } from '../../store/reducers'

// Sync route definition
export default (store) => ({
  path: 'orders/:orderId',
  getComponent (nextState, cb) {
    /*  Webpack - use 'require.ensure' to create a split point
        and embed an async module loader (jsonp) when bundling   */
    require.ensure([], (require) => {
      /*  Webpack - use require callback to define
          dependencies for bundling   */
      const Counter = require('./containers/ViewOrderContainer').default

      const reducer = require('./modules/ViewOrder').default
      const fixMessage = require('components/FixMessage/modules/FixMessage').default

      injectReducer(store, { key: 'FixMessage', reducer: fixMessage })
      injectReducer(store, { key: 'ViewOrder', reducer })

      /*  Return getComponent   */
      cb(null, Counter)

    /* Webpack named bundle   */
    }, 'viewOrder')
  }
})

import { searchOrders, mapSearchResponse, SEARCH_ORDERS_RESPONSE } from 'routes/Orders/modules/Orders'

export const actions = {
  searchOrders
}

// ------------------------------------
// Action Handlers
// ------------------------------------
const ACTION_HANDLERS = {
  [SEARCH_ORDERS_RESPONSE]: mapSearchResponse
}

// ------------------------------------
// Reducer
// ------------------------------------
const initialState = {
  rows: [],
  columns: []
}

export default function createOrderReducer (state = initialState, action) {
  const handler = ACTION_HANDLERS[action.type]

  return handler ? handler(state, action) : state
}

import React from 'react'
import {BootstrapTable, TableHeaderColumn} from 'react-bootstrap-table'
import { Link } from 'react-router'

export default class Orders extends React.Component {

  constructor (props) {
    super(props)
    this.state = {
      data: {
        accountNumber: this.props.accountNumber
      }
    }
  }

  handleChange = (e) => {
    this.state.data[e.target.id] = e.target.value
  }

  handleSubmit = (e) => {
    // Prevent refreshing form upon first submit
    e.preventDefault()
    this.props.searchOrders(this.state.data)
  }

  cancelOrderFormatter = (cell, row) => {
    const orderLink = `orders/${row.ClOrdID}`
    const cancelOrderLink = `cancelOrder?orderId=${row.ClOrdID}`

    return <span>
      <Link to={orderLink} title='Order Details' className='glyphicon glyphicon-file' />
      <Link to={cancelOrderLink} title='Order stornieren' className='glyphicon glyphicon-remove' />
    </span>
  }

  typeFormatter (cell, row) {
    const typeMapping = ['Market Order', 'Limit Order', 'Stop Order']
    return typeMapping[cell - 1] ? typeMapping[cell - 1] : ''
  }

  sideFormatter (cell, row) {
    const typeMapping = ['Kauf', 'Verkauf']
    return typeMapping[cell - 1] ? typeMapping[cell - 1] : ''
  }

  createTable () {
    const tableOptions = {
      defaultSortName: 'TransactTime',
      defaultSortOrder: 'desc'
    }

    return <BootstrapTable data={this.props.rows}
      height='190' options={tableOptions}
      striped hover condensed bordered={false} keyField='index'>
      <TableHeaderColumn dataField='SecurityDesc' width='150' dataSort>Wertpapier</TableHeaderColumn>
      <TableHeaderColumn dataField='Side' width='100' dataFormat={this.sideFormatter} dataSort>Art</TableHeaderColumn>
      <TableHeaderColumn dataField='OrdType' width='100'
        dataFormat={this.typeFormatter} dataSort>Type</TableHeaderColumn>
      <TableHeaderColumn dataField='OrderQty' width='100' dataSort>Menge</TableHeaderColumn>
      <TableHeaderColumn dataField='SecurityID' width='150' dataSort>WKN/ISIN</TableHeaderColumn>
      <TableHeaderColumn dataField='Text' width='150' dataSort>Text</TableHeaderColumn>
      <TableHeaderColumn dataField='Price' width='100' dataSort>Preis</TableHeaderColumn>
      <TableHeaderColumn dataField='index' width='50'
        dataFormat={this.cancelOrderFormatter} />
    </BootstrapTable>
  }

  render () {
    let table = null
    if (this.props.rows.length > 0 && this.props.columns.length > 0) {
      table = this.createTable()
    }

    return <div>
      <h4>Order anzeigen</h4>
      <form className='form-horizontal' onSubmit={this.handleSubmit}>
        <div className='form-group'>
          <label htmlFor='orderId' className='col-sm-2 control-label'>Order ID</label>
          <div className='col-sm-10'>
            <input type='text' className='form-control' name='orderId' id='orderId'
              onChange={this.handleChange} placeholder='Order ID eingeben (optional)' />
          </div>
        </div>
        <div className='form-group'>
          <div className='col-sm-offset-2 col-sm-10'>
            <button type='submit' className='btn btn-default'>Suchen</button>
          </div>
        </div>
      </form>
      {table}
    </div>
  }
}

Orders.propTypes = {
  accountNumber: React.PropTypes.string.isRequired,
  searchOrders: React.PropTypes.func.isRequired,
  rows: React.PropTypes.array.isRequired,
  columns: React.PropTypes.array.isRequired
}

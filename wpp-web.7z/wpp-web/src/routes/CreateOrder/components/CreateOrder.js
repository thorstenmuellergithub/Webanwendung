import React from 'react'
import FixMessage from 'components/FixMessage'
import moment from 'moment'

export default class CreateOrder extends React.Component {

  constructor (props) {
    super(props)
    this.state = this.getDefaultState(props)

    this.handleReset = this.handleReset.bind(this)
  }

  getDefaultState = (props) => {
    const timestamp = moment().format('YYMMDDHHmmssSS')
    const orderId = `W0${timestamp}:00001`

    return {
      accountNumber: props.accountNumber,
      orderId: orderId,
      isin: '',
      price: '',
      quantity: '',
      type: 1,
      orderType: '1',
      timeInForce: 0,
      expireDate: '20160731'
    }
  }

  handleChange = (e) => {
    const stateChange = {
      [e.target.id]: e.target.value
    }
    if (e.target.id === 'timeInForce' && e.target.value !== '6') {
      stateChange.expireDate = '20160731'
    }

    this.setState(stateChange)
  }

  changeType = (e) => {
    const typeNumber = parseInt(e.currentTarget.value)
    this.setState({
      type: typeNumber
    })
  }

  handleSubmit = (e) => {
    // Prevent refreshing form upon first submit
    e.preventDefault()

    if (this.refs.form.checkValidity()) {
      this.props.cleanFixMessage()
      this.props.createOrderFixMessage(this.state)
    }
  }

  handleReset = (e) => {
    // this.getDefaultState(this.props)
    this.setState(this.getDefaultState(this.props))
  }

  componentDidMount () {
    this.props.cleanFixMessage()
  }

  render () {
    let expireDate = null
    if (this.state.timeInForce === '6') {
      expireDate = <div className='form-group'>
        <label htmlFor='expireDate' className='col-sm-2 control-label'>Verfallsdatum</label>
        <div className='col-sm-10'>
          <input type='text' className='form-control' placeholder='YYYYMMDD'
            name='expireDate' id='expireDate' required onChange={this.handleChange} value={this.state.expireDate} />
        </div>
      </div>
    }

    let price = null
    if (this.state.orderType !== '1') {
      price = <div className='form-group'>
        <label htmlFor='amount' className='col-sm-2 control-label'>Preis</label>
        <div className='col-sm-10'>
          <input type='text' className='form-control'
            name='price' id='price' required onChange={this.handleChange} value={this.state.price} />
        </div>
      </div>
    }

    return <div>
      <h4>Order erstellen</h4>
      <form ref='form' className='form-horizontal' onSubmit={this.handleSubmit}>
        <div className='form-group'>
          <label className='col-sm-2 control-label' htmlFor='accountNumber'>Konto</label>
          <div className='col-sm-10'>
            <input type='text' className='form-control'
              name='accountNumber' id='accountNumber' required onChange={this.handleChange}
              value={this.state.accountNumber} />
          </div>
        </div>
        <div className='form-group'>
          <label className='col-sm-2 control-label' htmlFor='orderId'>Order ID</label>
          <div className='col-sm-10'>
            <input type='text' className='form-control'
              name='orderId' id='orderId' required onChange={this.handleChange}
              value={this.state.orderId} />
          </div>
        </div>
        <div className='form-group'>
          <label htmlFor='isin' className='col-sm-2 control-label'>ISIN</label>
          <div className='col-sm-10'>
            <input type='text' className='form-control'
              name='isin' id='isin' required onChange={this.handleChange}
              value={this.state.isin} />
          </div>
        </div>
        <div className='form-group'>
          <label htmlFor='amount' className='col-sm-2 control-label'>Menge</label>
          <div className='col-sm-10'>
            <input type='text' className='form-control'
              name='quantity' id='quantity' required onChange={this.handleChange}
              value={this.state.quantity} />
          </div>
        </div>
        <div className='form-group'>
          <label className='col-sm-2 control-label' htmlFor='tradeLocation'>Handelsplatz</label>
          <div className='col-sm-10'>
            <select className='form-control'
              name='tradeLocation' id='tradeLocation' required>
              <option value='160'>Xetra - 160</option>
            </select>
          </div>
        </div>
        <div className='form-group'>
          <div className='col-sm-offset-2 col-sm-10'>
            <label className='radio-inline'>
              <input type='radio' name='type' value='1'
                checked={this.state.type === 1} onChange={this.changeType} />Ankauf</label>
            <label className='radio-inline'>
              <input type='radio' name='type' value='2'
                checked={this.state.type === 2} onChange={this.changeType} />Verkauf</label>
          </div>
        </div>
        <div className='form-group'>
          <label className='col-sm-2 control-label' htmlFor='orderType'>OrderType</label>
          <div className='col-sm-10'>
            <select className='form-control'
              name='orderType' id='orderType' required onChange={this.handleChange} value={this.state.orderType}>
              <option value='1'>Market Order</option>
              <option value='2'>Limit Order</option>
            </select>
          </div>
        </div>
        {price}
        <div className='form-group'>
          <label className='col-sm-2 control-label' htmlFor='timeInForce'>Gültigkeit</label>
          <div className='col-sm-10'>
            <select className='form-control'
              name='timeInForce' id='timeInForce' required onChange={this.handleChange} value={this.state.timeInForce}>
              <option value='0'>Day (or session)</option>
              <option value='1'>Good Till Cancel (GTC)</option>
              <option value='2'>At the Opening (OPG)</option>
              <option value='3'>Immediate Or Cancel (IOC)</option>
              <option value='4'>Fill Or Kill (FOK)</option>
              <option value='5'>Good Till Crossing (GTX)</option>
              <option value='6'>Good Till Date (GTD)</option>
              <option value='7'>At the Close</option>
            </select>
          </div>
        </div>
        {expireDate}
        <div className='form-group'>
          <div className='col-sm-offset-2 col-sm-4'>
            <button type='submit' className='btn btn-default'>FIX Nachricht Erstellen</button>
          </div>
          <div className='col-sm-6'>
            <button type='button' className='btn btn-default' onClick={this.handleReset}>Reset</button>
          </div>
        </div>
      </form>
      <FixMessage fixMessage={this.props.fixMessage} sendFixMessage={this.props.sendFixMessage}
        fixMessageResponse={this.props.fixMessageResponse} />
    </div>
  }
}

CreateOrder.propTypes = {
  accountNumber: React.PropTypes.string.isRequired,
  fixMessage: React.PropTypes.string.isRequired,
  fixMessageResponse: React.PropTypes.string.isRequired,
  createOrderFixMessage: React.PropTypes.func.isRequired,
  cleanFixMessage: React.PropTypes.func.isRequired,
  sendFixMessage: React.PropTypes.func.isRequired
}

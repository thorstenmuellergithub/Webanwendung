import <%= pascalEntityName %>View from './<%= pascalEntityName %>View'
export default <%= pascalEntityName %>View

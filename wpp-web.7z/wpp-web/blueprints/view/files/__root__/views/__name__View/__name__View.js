import React from 'react'

type Props = {

};
export class <%= pascalEntityName %> extends React.Component {
  props: Props;

  render () {
    return (
      <div></div>
    )
  }
}

export default <%= pascalEntityName %>

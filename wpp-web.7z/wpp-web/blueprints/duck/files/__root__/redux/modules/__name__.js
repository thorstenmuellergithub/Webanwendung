// Constants
// export const constants = { }

// Action Creators
// export const actions = { }

// Reducer
export const initialState = {}
export default function (state = initialState, action) {
  switch (action.type) {
    default:
      return state
  }
}
